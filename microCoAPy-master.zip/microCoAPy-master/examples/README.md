this folder will be populated with examples describing the usage of the library on various platforms and technologies
