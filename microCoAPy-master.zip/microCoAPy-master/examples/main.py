print("hello from microCoAPy example main")

import sys
sys.path.append("/flash/lib/external")

sys.path.append("/flash/pycom/nbiot")
import pycom_nbiot_coap_client

#sys.path.append("/flash/pycom/wifi")
#import pycom_wifi_coap_client
#import pycom_wifi_coap_server

#sys.path.append("/esp/wifi")
#import esp_wifi_coap_server
#import esp_wifi_coap_client
#import esp_wifi_coap_client_custom_socket
